public class Admin extends User {

    public Admin(int userID, String name, String email, String password, String address, String phone, String profilePicture) {
        super(userID, name, email, password, address, phone, profilePicture);
    }

    // Method to manage products
    public void manageProduct(Product product) {
        // Logic to manage product
    }

    // Method to manage stock
    public void manageStock(Product product, int newStock) {
        product.setStock(newStock);
    }
}
