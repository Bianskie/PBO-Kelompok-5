import java.util.List;

public class Order {
    private int orderID;
    private User user;
    private List<Product> productList;
    private double totalAmount;
    private String paymentStatus;
    private String shippingStatus;

    // Constructor
    public Order(int orderID, User user, List<Product> productList, double totalAmount, String paymentStatus, String shippingStatus) {
        this.orderID = orderID;
        this.user = user;
        this.productList = productList;
        this.totalAmount = totalAmount;
        this.paymentStatus = paymentStatus;
        this.shippingStatus = shippingStatus;
    }

    // Getters and Setters
    public int getOrderID() { return orderID; }
    public void setOrderID(int orderID) { this.orderID = orderID; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public List<Product> getProductList() { return productList; }
    public void setProductList(List<Product> productList) { this.productList = productList; }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    public String getShippingStatus() { return shippingStatus; }
    public void setShippingStatus(String shippingStatus) { this.shippingStatus = shippingStatus; }
}
