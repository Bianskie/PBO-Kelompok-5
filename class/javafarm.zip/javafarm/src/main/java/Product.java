public class Product {
    private int productID;
    private String productName;
    private String description;
    private double price;
    private int stock;
    private Category category;
    private String images;

    // Constructor
    public Product(int productID, String productName, String description, double price, int stock, Category category, String images) {
        this.productID = productID;
        this.productName = productName;
        this.description = description;
        this.price = price;
        this.stock = stock;
        this.category = category;
        this.images = images;
    }

    // Getters and Setters
    public int getProductID() { return productID; }
    public void setProductID(int productID) { this.productID = productID; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }

    public String getImages() { return images; }
    public void setImages(String images) { this.images = images; }
}
