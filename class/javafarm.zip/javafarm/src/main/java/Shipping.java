public class Shipping {
    private int shippingID;
    private String shippingAddress;
    private String shippingMethod;
    private String shippingStatus;

    // Constructor
    public Shipping(int shippingID, String shippingAddress, String shippingMethod, String shippingStatus) {
        this.shippingID = shippingID;
        this.shippingAddress = shippingAddress;
        this.shippingMethod = shippingMethod;
        this.shippingStatus = shippingStatus;
    }

    // Getters and Setters
    public int getShippingID() { return shippingID; }
    public void setShippingID(int shippingID) { this.shippingID = shippingID; }

    public String getShippingAddress() { return shippingAddress; }
    public void setShippingAddress(String shippingAddress) { this.shippingAddress = shippingAddress; }

    public String getShippingMethod() { return shippingMethod; }
    public void setShippingMethod(String shippingMethod) { this.shippingMethod = shippingMethod; }

    public String getShippingStatus() { return shippingStatus; }
    public void setShippingStatus(String shippingStatus) { this.shippingStatus = shippingStatus; }
}
