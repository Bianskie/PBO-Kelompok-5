package com.mycompany.javafarm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Javafarm {
    public static void main(String[] args) {
        System.out.println("Sistem JavaFarm dimulai...");

        // Buat koneksi ke database menggunakan JDBC
        String jdbcUrl = "jdbc:mysql://localhost:3306/Java_Farm";  // Ubah 'Java_Farm' sesuai dengan database kamu
        String username = "root";  // Ganti dengan username MySQL kamu
        String password = "";  // Ganti dengan password MySQL kamu

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            if (connection != null) {
                System.out.println("Koneksi ke database berhasil!");
            } else {
                System.out.println("Gagal melakukan koneksi ke database.");
            }
        } catch (SQLException e) {
            System.out.println("Terjadi kesalahan saat mencoba menghubungi database.");
            e.printStackTrace();
        }

        // Logika aplikasi lainnya bisa ditambahkan di sini
    }
}
